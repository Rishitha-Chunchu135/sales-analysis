# Sales Analysis using SQL

## Project Description
This project analyzes sales data using SQL.

## Steps to Run the SQL code
1. Run schema.sql
2. Run data.sql
3. Run queries.sql

## Features
- Top products
- Customer analysis
- Revenue tracking