

import tkinter as tk
from tkinter import ttk, messagebox
import csv
import os
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt

file_name = "expenses.csv"



def setup_file():
    if not os.path.exists(file_name):
        with open(file_name, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Date", "Category", "Amount", "Description"])



def add_expense():
    date = date_entry.get().strip()
    category = category_entry.get().strip()
    amount = amount_entry.get().strip()
    desc = desc_entry.get().strip()

    
    if date == "":
        date = datetime.today().strftime("%Y-%m-%d")

    
    if category == "" or amount == "":
        messagebox.showerror("Error", "Please enter category and amount")
        return

    try:
        amount = float(amount)
    except:
        messagebox.showerror("Error", "Amount should be a number")
        return

    
    with open(file_name, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([date, category, amount, desc])

    messagebox.showinfo("Done", "Expense added successfully!")

    clear_inputs()
    show_data()



def show_data():
   
    for item in tree.get_children():
        tree.delete(item)

    with open(file_name, "r") as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            tree.insert("", tk.END, values=row)



def clear_inputs():
    date_entry.delete(0, tk.END)
    category_entry.delete(0, tk.END)
    amount_entry.delete(0, tk.END)
    desc_entry.delete(0, tk.END)



def show_summary():
    try:
        df = pd.read_csv(file_name)
        df["Date"] = pd.to_datetime(df["Date"])

        month = int(month_entry.get())
        year = int(year_entry.get())

        data = df[(df["Date"].dt.month == month) & (df["Date"].dt.year == year)]

        total = data["Amount"].sum()

        messagebox.showinfo("Summary", f"Total spent: ₹{total:.2f}")

    except:
        messagebox.showerror("Error", "Enter valid month/year")



def show_graph():
    try:
        df = pd.read_csv(file_name)

        grouped = df.groupby("Category")["Amount"].sum()

        top_category = grouped.idxmax()
        messagebox.showinfo("Insight", f"You spend most on: {top_category}")

        plt.figure(figsize=(6, 6))
        plt.pie(grouped, labels=grouped.index, autopct="%1.1f%%")
        plt.title("Expenses by Category")
        plt.show()

    except:
        messagebox.showerror("Error", "No data to display")




root = tk.Tk()
root.title("Expense Tracker")
root.geometry("900x600")

setup_file()

main_frame = tk.Frame(root, padx=10, pady=10)
main_frame.pack(fill="x")


tk.Label(main_frame, text="Date (YYYY-MM-DD)").grid(row=0, column=0)
date_entry = tk.Entry(main_frame)
date_entry.grid(row=0, column=1)

tk.Label(main_frame, text="Category").grid(row=0, column=2)
category_entry = tk.Entry(main_frame)
category_entry.grid(row=0, column=3)

tk.Label(main_frame, text="Amount").grid(row=1, column=0)
amount_entry = tk.Entry(main_frame)
amount_entry.grid(row=1, column=1)

tk.Label(main_frame, text="Description").grid(row=1, column=2)
desc_entry = tk.Entry(main_frame)
desc_entry.grid(row=1, column=3)


tk.Button(main_frame, text="Add", command=add_expense).grid(row=2, column=0, pady=10)
tk.Button(main_frame, text="Clear", command=clear_inputs).grid(row=2, column=1)
tk.Button(main_frame, text="Chart", command=show_graph).grid(row=2, column=2)
tk.Button(main_frame, text="Summary", command=show_summary).grid(row=2, column=3)


tk.Label(main_frame, text="Month").grid(row=3, column=0)
month_entry = tk.Entry(main_frame)
month_entry.grid(row=3, column=1)

tk.Label(main_frame, text="Year").grid(row=3, column=2)
year_entry = tk.Entry(main_frame)
year_entry.grid(row=3, column=3)


cols = ("Date", "Category", "Amount", "Description")
tree = ttk.Treeview(root, columns=cols, show="headings")

for c in cols:
    tree.heading(c, text=c)
    tree.column(c, anchor="center")

tree.pack(fill="both", expand=True, padx=10, pady=10)

show_data()

root.mainloop()