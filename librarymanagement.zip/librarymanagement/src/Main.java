import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        BookManager bm = new BookManager();
        UserManager um = new UserManager();
        TransactionManager tm = new TransactionManager();

        while (true) {
            System.out.println("\n===== Library System =====");
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Add User");
            System.out.println("4. Issue Book");
            System.out.println("5. Return Book");
            System.out.println("6. Exit");

            int choice = sc.nextInt();

            switch (choice) {
                case 1: bm.addBook(); break;
                case 2: bm.viewBooks(); break;
                case 3: um.addUser(); break;
                case 4: tm.issueBook(); break;
                case 5: tm.returnBook(); break;
                case 6: System.exit(0);
                default: System.out.println("Invalid choice!");
            }
        }
    }
}