import java.sql.*;
import java.util.Scanner;

public class UserManager {

    public void addUser() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter User Name: ");
        String name = sc.nextLine();

        try {
            Connection con = DBConnection.getConnection();
            String query = "INSERT INTO users(name) VALUES(?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);

            ps.executeUpdate();
            System.out.println("User Added!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}