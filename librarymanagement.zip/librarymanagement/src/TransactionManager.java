import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class TransactionManager {

    public void issueBook() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Book ID: ");
        int bookId = sc.nextInt();

        System.out.print("Enter User ID: ");
        int userId = sc.nextInt();

        try {
            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO transactions(book_id, user_id, issue_date) VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, bookId);
            ps.setInt(2, userId);
            ps.setDate(3, Date.valueOf(LocalDate.now()));

            ps.executeUpdate();
            System.out.println("Book Issued!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void returnBook() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Transaction ID: ");
        int transId = sc.nextInt();

        try {
            Connection con = DBConnection.getConnection();

            String selectQuery = "SELECT issue_date FROM transactions WHERE trans_id=?";
            PreparedStatement ps1 = con.prepareStatement(selectQuery);
            ps1.setInt(1, transId);

            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                LocalDate issueDate = rs.getDate("issue_date").toLocalDate();
                LocalDate returnDate = LocalDate.now();

                long days = ChronoUnit.DAYS.between(issueDate, returnDate);

                double fine = 0;
                if (days > 7) {
                    fine = (days - 7) * 10; // ₹10 per day
                }

                String updateQuery = "UPDATE transactions SET return_date=?, fine=? WHERE trans_id=?";
                PreparedStatement ps2 = con.prepareStatement(updateQuery);

                ps2.setDate(1, Date.valueOf(returnDate));
                ps2.setDouble(2, fine);
                ps2.setInt(3, transId);

                ps2.executeUpdate();

                System.out.println("Book Returned! Fine: ₹" + fine);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}